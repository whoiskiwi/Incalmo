
<% response.sendRedirect("main.action"); %>

